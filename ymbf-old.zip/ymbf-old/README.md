<h1 align="center">
  YMBF
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://www.facebook.com/KM39453">YayanXD_</a>
</p>
<p align="center">
 
### menu
 <img src="https://github.com/Yayan-XD/ymbf/blob/main/.ppk/carbon.png" width="640" title="Menu" alt="Menu">
</p>

#### Results
 <img src="https://github.com/Yayan-XD/ymbf/blob/main/.ppk/hasil.jpg" width="640" title="Menu" alt="Menu">
</p>

###### notice me: if you get cp results, save 3/7 days then log in.

<a href="https://github.com/Yayan-XD/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Yayan-XD?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Yayan-XD/termux-style/stargazers/">
  <a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Yayan-XD/ymbf.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Yayan-XD/ymbf.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Search" src="https://img.shields.io/github/search/Yayan-XD/Craker/ymbf.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Starts" src="https://img.shields.io/github/stars/Yayan-XD/ymbf.svg"/>
  </a>
<a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Yayan-XD/ymbf.svg"/>
  </a>

<a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Yayan-XD/ymbf.svg"/> <a href="https://github.com/Yayan-XD/ymbf">
    <img alt="Forks" src="https://img.shields.io/github/forks/Yayan-XD/ymbf.svg"/>
  </a>
</div>
<p align="center">

#### Install script on Termux
```bash
$ pkg update && pkg upgrade
$ pkg install python2
$ pkg install git
$ git clone https://github.com/Yayan-XD/ymbf
$ pip2 install requests bs4
$ pip2 install futures
```
#### Run script
```bash
$ cd ymbf
$ python2 ymbf.py
```
#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Yayan-XD) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/moch_xd)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/KM39453)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/yayanxd_/) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6285603036683?text=Asalamualaikum+bang)

##### catatan:
gunakanlah dengan bijak, atas apapun yang terjadi admin tidak bertanggung jawab.


##### Notice Me : Please Don't Change Name Author Thanks For Using My Script
